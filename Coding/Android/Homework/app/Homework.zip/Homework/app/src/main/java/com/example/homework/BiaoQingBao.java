package com.example.homework;

public class BiaoQingBao {
    private String name;
    private int imageId;
    public BiaoQingBao(String name,int imageId){
        this.name=name;
        this.imageId=imageId;
    }
    public String getName(){
        return name;
    }
    public int getImageId(){
        return imageId;
    }

}
